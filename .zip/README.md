# Sarvam4All Project By CrypticNomand Team in Great Bengaluru Hackathon

# How to Run the Web APP

Temporarily until the evaluation we are putting our private keys in our .env file
so no need to setup

Run command

Install dependencies
> npm install
> npm run dev


Enjoy!

Note:after Results are out .env file shall be made private

Further setup
> Go to APPwrite console
> Create a project
> ...
> I'm lazy i'll do later


# Running the Whatsapp App
> cd Whatsapp

> node index.js

