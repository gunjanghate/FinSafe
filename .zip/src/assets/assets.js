import banner from './banner.webp';
import iconlogo from './logo-icon.svg';
import logoLight from './logo-light.svg';
import logoDark from './logo-dark.svg';


export {banner, iconlogo, logoLight, logoDark};
